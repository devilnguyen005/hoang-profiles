HOANG PORTFOLIO

1. Mở thư mục bằng VS Code.
2. Mở index.html bằng trình duyệt hoặc dùng Live Server.
3. Thay assets/avatar.jpg bằng ảnh cá nhân nếu cần.
4. Khi hoàn thiện, upload toàn bộ thư mục lên Cloudflare Pages, Vercel hoặc GitHub Pages.
5. Lấy link website tạo QR để đưa vào CV Canva.
